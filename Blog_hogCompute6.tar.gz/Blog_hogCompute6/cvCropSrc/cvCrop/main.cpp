#include <cv.h>
#include <highgui.h>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "cvaux.h"
//using namespace std;
int main(int argc , char ** argv)
{
    IplImage* src ;
    IplImage* dst = 0;

    CvSize dst_size;

    FILE* f = 0;
    char _filename[1024];
    int l;
    bool IsNegSet = false;
    bool IsCentralSet = false;
    bool IsRandNegSet = false;
    if(argc == 2)
    {
         f = fopen(argv[1], "rt");
    }else if(argc == 3)
    {
    if(!strcmp(argv[1],"-n"))
        IsNegSet = true;
    if(!strcmp(argv[1],"-r"))
        IsRandNegSet = true;
    if(!strcmp(argv[1],"-c"))
        IsCentralSet = true;
    f = fopen(argv[2], "rt");
    }else
    fprintf(stderr, "Error! too many argument\n");
    if(!f)
    {
        fprintf( stderr, "ERROR: the specified file could not be loaded\n");
        return -1;
    }

    for(;;)
    {
        char* filename = _filename;
        if(f)
        {
            if(!fgets(filename, (int)sizeof(_filename)-2, f))
                break;
            if(filename[0] == '#')
                continue;
            l = strlen(filename);
            while(l > 0 && isspace(filename[l-1]))
                --l;
            filename[l] = '\0';
            src=cvLoadImage(filename,1);
        }
        if(IsCentralSet)
        {

            for(int j=0;j<src->height-128;j=j+4)
            {
               for(int i=0;i<src->width-64;i=i+4)
                {

                    cvSetImageROI(src, cvRect(i, j, 64, 128));

                    IplImage *dst= cvCreateImage(cvGetSize(src), src->depth, src->nChannels);
                    cvCopy(src, dst, NULL);
                   // cvResize(src,dst,CV_INTER_LINEAR);//////////////////
                    char filename2[1024],filenum[5]; strcpy(filename2,_filename);char* filename3 = _filename; filename3="_64x128.jpg";
                    sprintf(filenum,"%d_%d",i,j);

                    strcat(filename2,filenum);
                      strcat(filename2, filename3);

                    std::cout << cvSaveImage(filename2, dst);
                }
            }
        }else
        if(IsNegSet)
        {
            int cutx=0,cuty=0;
            for(int j=0;j<10;j++)
            {
                cutx+=j*16;
                if(cutx  > src->width - 64)
                {
                    cutx=0; cuty+=16;
                    if(cuty > src->height - 128)
                        break;

                }
                cvSetImageROI(src, cvRect(cutx, cuty, 64, 128));

                IplImage *dst= cvCreateImage(cvGetSize(src), src->depth, src->nChannels);
                cvCopy(src, dst, NULL);
               // cvResize(src,dst,CV_INTER_LINEAR);//////////////////
                char filename2[1024],filenum[5]; strcpy(filename2,_filename);char* filename3 = _filename; filename3="_64x128.jpg";
                sprintf(filenum,"%d",j);

                strcat(filename2,filenum);
                  strcat(filename2, filename3);

                std::cout << cvSaveImage(filename2, dst);
            }
        }else if(IsRandNegSet)
        {
            int cutx,cuty,maxX,maxY;
            maxX = src->width - 64;
            maxY = src->height - 128;
            srand((unsigned)time(0));
            for(int j=0;j<10;j++)
            {
               cutx = rand()%maxX;
               cuty = rand()%maxY;
                cvSetImageROI(src, cvRect(cutx, cuty, 64, 128));

                IplImage *dst= cvCreateImage(cvGetSize(src), src->depth, src->nChannels);
                cvCopy(src, dst, NULL);
               // cvResize(src,dst,CV_INTER_LINEAR);//////////////////
                char filename2[1024],filenum[5]; strcpy(filename2,_filename);char* filename3 = _filename; filename3="_64x128.jpg";
                sprintf(filenum,"%d",j);

                strcat(filename2,filenum);
                  strcat(filename2, filename3);

                std::cout << cvSaveImage(filename2, dst);
            }
        }
        else
        {
            cvSetImageROI(src, cvRect(16, 16, 64, 128));


        IplImage *dst= cvCreateImage(cvGetSize(src), src->depth, src->nChannels);
        cvCopy(src, dst, NULL);
       // cvResize(src,dst,CV_INTER_LINEAR);//////////////////
        char filename2[1024]; strcpy(filename2,_filename);char* filename3 = _filename; filename3="_64x128.jpg";

        strcat(filename2, filename3);

        std::cout << cvSaveImage(filename2, dst);
        }

    }
    if(f)
        fclose(f);

    //cvWaitKey(-1);
    cvReleaseImage( &src );
    cvReleaseImage( &dst );




    return 0;
}
