package hog;

public interface Voter {
	public float vote(float magnitude);
}
 																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																