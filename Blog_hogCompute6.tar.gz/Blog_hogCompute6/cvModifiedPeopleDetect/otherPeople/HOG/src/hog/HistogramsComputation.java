package hog;

public interface HistogramsComputation {
	public Histogram[][] computeHistograms(PixelGradientVector[][] pgv);
}
