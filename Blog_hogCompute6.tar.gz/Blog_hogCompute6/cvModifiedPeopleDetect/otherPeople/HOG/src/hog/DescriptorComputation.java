package hog;

public interface DescriptorComputation {
	public float[] computeDescriptor(Block[][] blocks);
}
