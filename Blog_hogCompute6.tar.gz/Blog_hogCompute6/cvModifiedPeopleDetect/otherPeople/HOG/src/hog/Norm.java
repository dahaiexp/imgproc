package hog;

public interface Norm {
	public float[] normalize(float[] vector);
}
