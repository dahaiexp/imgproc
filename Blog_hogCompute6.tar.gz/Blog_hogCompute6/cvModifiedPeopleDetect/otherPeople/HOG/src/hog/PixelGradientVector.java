package hog;

public class PixelGradientVector {
	private float magnitude;
	private float angle;
	public PixelGradientVector(float magnitude, float angle) {
		this.magnitude=magnitude;
		this.angle=angle;
	}
	public float getMagnitude() {
		// TODO Auto-generated method stub
		return magnitude;
	}
	public float getAngle() {
		// TODO Auto-generated method stub
		return angle;
	}
}
