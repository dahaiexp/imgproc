rm -rf test train
rm *.txt *.dat
