awk -F, '{print NF}'  $1
wc -l $1
