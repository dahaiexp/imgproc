plugin_name  = "Error2"

def create(callback):
    raise "Error2"
